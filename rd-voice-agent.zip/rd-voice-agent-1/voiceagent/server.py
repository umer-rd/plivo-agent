import asyncio
import base64
import json
import os
import sys
import io
import traceback
import numpy as np
import wave
from openai import AsyncOpenAI
import requests
from aiohttp import web, WSMsgType
import aiohttp_cors
import hashlib
import re
import time
from collections import deque
from assemblyai_streaming import AssemblyAITranscriptionManager


# Get API keys from environment variables
ASSEMBLYAI_API_KEY = os.environ.get('ASSEMBLYAI_API_KEY')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
UNREAL_SPEECH_API_KEY = os.environ.get('UNREAL_SPEECH_API_KEY')
OPENAI_MODEL = os.environ.get('OPENAI_MODEL', 'gpt-4.1-mini')  # Default to latest optimized model
PLIVO_AUTH_ID = os.environ.get('PLIVO_AUTH_ID')
PLIVO_AUTH_TOKEN = os.environ.get('PLIVO_AUTH_TOKEN')
WEBSOCKET_AUTH_TOKEN = os.environ.get('WEBSOCKET_AUTH_TOKEN')
if not WEBSOCKET_AUTH_TOKEN:
    print("⚠️  Warning: WEBSOCKET_AUTH_TOKEN not set. Using demo token for development.")
    print("🔒 For production: Set a strong WEBSOCKET_AUTH_TOKEN in environment variables")
    WEBSOCKET_AUTH_TOKEN = 'demo-token-change-in-production'

# Validate that essential API keys are present (only those needed at startup)
if not all([ASSEMBLYAI_API_KEY, OPENAI_API_KEY, UNREAL_SPEECH_API_KEY]):
    print("Error: Missing required API keys (ASSEMBLYAI_API_KEY, OPENAI_API_KEY, UNREAL_SPEECH_API_KEY). Please check your environment variables.")
    sys.exit(1)

# Warn about optional Plivo credentials (only needed when calls are made)
if not PLIVO_AUTH_ID or not PLIVO_AUTH_TOKEN:
    print("Warning: PLIVO_AUTH_ID and PLIVO_AUTH_TOKEN are not set. These will be needed for phone call functionality.")

# Create client for OpenAI API using environment variables
openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY)

# Unreal Speech configuration
UNREAL_SPEECH_BASE_URL = 'https://api.v8.unrealspeech.com'
UNREAL_SPEECH_VOICE = 'Emily'  # High-quality female voice


# Initialize message list with system instructions for OpenAI (will be per-session)
messages = []


# System instructions for the assistant's personality and tone
system_msg = """You are Alex, Tech Hospital's AI receptionist. We repair phones, tablets, computers, and game consoles. For phone repairs: 1) Get name first 2) Identify exact model 3) Ask about the issue 4) Offer same-day appointment 5) Confirm details. Always get name before quotes. Push same-day appointments. Mention $39 diagnostic fee (goes toward repair cost) when booking. iPhone 16 Pro Screen: $100+tax. Address: 1235 West Street, across from Dairy Queen, Delaware. 12% GST if asked. Output in one paragraph."""

# Legacy global messages list (unused - session_messages used instead)
messages = []




# AssemblyAI streaming transcription manager with intelligent turn detection
transcription_manager = None

async def setup_transcription_session(session_messages, ws):
    """Setup AssemblyAI streaming session for real-time transcription with turn detection."""
    global transcription_manager
    
    try:
        transcription_manager = AssemblyAITranscriptionManager()
        
        # Callback for handling completed turns (when speaker finishes talking)
        async def on_turn_complete(transcript):
            if transcript and transcript.strip():
                print(f"🗣️ Turn completed: {transcript}")
                
                # Process the transcription just like before
                session_messages.append({"role": "user", "content": transcript})
                
                
                # Generate AI response
                try:
                    response = await openai_client.chat.completions.create(
                        model=OPENAI_MODEL,
                        messages=session_messages,
                        max_tokens=150,
                        temperature=0.7
                    )
                    
                    ai_message = response.choices[0].message.content
                    session_messages.append({"role": "assistant", "content": ai_message})
                    
                    # Convert AI response to speech and send
                    if ai_message and ai_message.strip():
                        response_duration = await send_streaming_tts(ai_message, ws)
                    else:
                        response_duration = 0
                    
                    if response_duration > 0:
                        print(f"🎵 AI speaking for {response_duration:.1f}s")
                        await asyncio.sleep(response_duration)
                        
                except Exception as e:
                    print(f"Error generating AI response: {e}")
                    traceback.print_exc()
        
        # Callback for real-time transcript updates (partial results)
        def on_transcript_update(transcript):
            # For now, just log partial transcripts - we act on complete turns
            if transcript.strip():
                print(f"📝 Partial: {transcript}")
        
        # Store the current event loop for thread-safe callback execution
        main_event_loop = asyncio.get_running_loop()
        
        # Create AssemblyAI streaming session with proper thread-safe async callback
        def sync_on_turn_complete(transcript):
            # Schedule coroutine from different thread using the stored main loop
            if transcript and transcript.strip():
                try:
                    asyncio.run_coroutine_threadsafe(on_turn_complete(transcript), main_event_loop)
                except Exception as e:
                    print(f"⚠️ Error scheduling async callback: {e}")
        
        streaming_client = await transcription_manager.create_session(
            on_transcript=on_transcript_update,
            on_turn_end=sync_on_turn_complete
        )
        
        # Start the streaming session
        streaming_client.start_streaming()
        print("🎯 AssemblyAI streaming session established with turn detection")
        
        return streaming_client
        
    except Exception as e:
        print(f"❌ Failed to setup AssemblyAI session: {e}")
        traceback.print_exc()
        return None

async def cleanup_transcription_session():
    """Clean up the AssemblyAI streaming session."""
    global transcription_manager
    if transcription_manager:
        try:
            await transcription_manager.close_session()
            print("🔚 AssemblyAI session closed")
        except Exception as e:
            print(f"Error closing AssemblyAI session: {e}")
        finally:
            transcription_manager = None


# 🚀 TRUE PARALLEL: Generate response using OpenAI streaming with non-blocking TTS
async def generate_response(input_text, plivo_ws, session_messages):
    # Validate input text
    if not input_text or not isinstance(input_text, str) or not input_text.strip():
        print("⚠️ Invalid input text, skipping response generation")
        return 0
    
    
    # Append user input to the conversation history
    session_messages.append({"role": "user", "content": input_text})
    
    # 🚀 CONTEXT TRIMMING: Prevent exponential token growth
    MAX_MESSAGES = 7  # System + last 6 messages (3 exchanges)
    if len(session_messages) > MAX_MESSAGES:
        # Keep system message + last 6 messages (mutate in place!)
        trimmed = [session_messages[0]] + session_messages[-6:]
        session_messages[:] = trimmed
        print(f"🔄 Context trimmed to {len(session_messages)} messages for speed")

    try:
        # 🚀 STREAMING OPENAI: Start streaming response for faster perceived latency
        print("🚀 Starting truly parallel streaming OpenAI response...")
        
        stream = await asyncio.wait_for(
            openai_client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=session_messages,
                stream=True,  # ⚡ Enable streaming for faster response
                max_tokens=120,  # 🚀 Limit response length for speed
                temperature=0.7,  # 🚀 Faster than default 1.0
                presence_penalty=0.1  # 🚀 Reduce repetition
            ),
            timeout=12.0  # 🚀 Reduced timeout for faster failures
        )

        # 🚀 STREAMING COLLECTION: Collect entire OpenAI response for Unreal Speech streaming
        full_response = ""
        
        print("📡 Collecting complete OpenAI response for streaming TTS...")
        
        # 🚧 STREAMING TIMEOUT: Prevent infinite hangs
        stream_start_time = time.time()
        async for chunk in stream:
            # Check for streaming timeout (20s max for entire response)
            if time.time() - stream_start_time > 20.0:
                print("⚠️ OpenAI streaming timeout exceeded, finalizing response")
                break
            if chunk.choices and chunk.choices[0].delta.content:
                content = chunk.choices[0].delta.content
                full_response += content
        
        print(f"✅ Complete OpenAI response collected: '{full_response[:100]}...'")
        
        # Validate we got a response before sending to TTS
        if not full_response or not full_response.strip():
            print("⚠️ Empty response from OpenAI, using fallback")
            fallback_reply = "I'm sorry, I didn't catch that. Could you please repeat your question?"
            return await send_streaming_tts(fallback_reply, plivo_ws)
        
        # 🎵 STREAMING TTS: Send complete response to Unreal Speech streaming API
        total_duration = await send_streaming_tts(full_response.strip(), plivo_ws)

        # Append assistant response to the conversation history
        session_messages.append({"role": "assistant", "content": full_response.strip()})
        print(f"🎵 Total TTS duration: {total_duration:.1f}s")
        print(f"🔄 Session context: {len(session_messages)} messages")
        
        return total_duration  # Return total duration for speaking state management
        
    except asyncio.TimeoutError:
        print("❌ OpenAI API timeout - response took longer than 12 seconds")
        fallback_reply = "I'm having trouble processing that right now. Could you please try again?"
        return await send_streaming_tts(fallback_reply, plivo_ws)
        
    except Exception as e:
        print(f"❌ Error with OpenAI API: {str(e)}")
        traceback.print_exc()
        fallback_reply = "I'm sorry, I'm experiencing technical difficulties. Please try again."
        return await send_streaming_tts(fallback_reply, plivo_ws)


# Sends pre-generated greeting audio for instant playback (0ms TTS latency)
async def send_greeting_audio(plivo_ws):
    """Send pre-generated greeting audio immediately upon connection"""
    greeting_path = os.path.join(os.path.dirname(__file__), 'greeting.mulaw')
    
    try:
        # Try to load pre-generated greeting file
        if os.path.exists(greeting_path):
            with open(greeting_path, 'rb') as f:
                greeting_audio = f.read()
            
            # Calculate audio duration for proper timing (μ-law at 8kHz)
            duration_seconds = len(greeting_audio) / 8000.0 + 0.5  # Add 500ms buffer
            
            # Encode and send immediately (0ms TTS latency!)
            encode = base64.b64encode(greeting_audio).decode('utf-8')
            audio_message = json.dumps({
                "event": "playAudio",
                "media": {
                    "contentType": "audio/x-mulaw",
                    "sampleRate": 8000,
                    "payload": encode
                }
            })
            
            print(f"📞 Sending instant greeting: {len(greeting_audio)} bytes (duration: {duration_seconds:.1f}s)")
            
            # 🛡️ CHECK WEBSOCKET CONNECTION BEFORE SENDING
            if plivo_ws.closed:
                print("⚠️ WebSocket connection is closed, skipping greeting")
                return 0
            
            try:
                # Send via WebSocket
                if hasattr(plivo_ws, 'send_str'):
                    await plivo_ws.send_str(audio_message)
                else:
                    await plivo_ws.send(audio_message)
                return duration_seconds  # Return duration for speaking state management
            except Exception as e:
                print(f"❌ Failed to send greeting: {str(e)}")
                return 0
            
        else:
            print(f"⚠️ Greeting file not found: {greeting_path}")
            # Fallback to real-time TTS
            return await send_streaming_tts("It's a beautiful day at Tech Hospital, how can I help you today?", plivo_ws)
            
    except Exception as e:
        print(f"❌ Error sending greeting: {str(e)}")
        # Fallback to real-time TTS
        return await send_streaming_tts("It's a beautiful day at Tech Hospital, how can I help you today?", plivo_ws)

# 🚀 STREAMING TTS: Use Unreal Speech streaming API for complete responses
async def send_streaming_tts(text: str, plivo_ws):
    """Send complete text to Unreal Speech streaming API and stream audio to Plivo"""
    
    # Run Unreal Speech streaming TTS in thread executor to avoid blocking event loop
    def generate_streaming_tts():
        try:
            print(f"🎵 Generating streaming TTS for: '{text[:100]}...'")
            response = requests.post(
                f'{UNREAL_SPEECH_BASE_URL}/stream',
                headers={'Authorization': f'Bearer {UNREAL_SPEECH_API_KEY}'},
                json={
                    'Text': text,
                    'VoiceId': UNREAL_SPEECH_VOICE,
                    'Bitrate': '16k',      # Ultra-low bitrate for SPEED
                    'Speed': '0',          # Normal speed
                    'Pitch': '1',          # Normal pitch
                    'Codec': 'pcm_mulaw', # μ-law format for perfect Plivo compatibility
                    'SampleRate': 8000    # Explicit 8kHz for telephony
                },
                timeout=15  # Longer timeout for complete response
            )
            
            if response.status_code == 200:
                return bytearray(response.content)
            elif response.status_code >= 500:
                print(f"Unreal Speech server error ({response.status_code}): {response.text[:100]}")
            elif response.status_code == 401:
                print("Unreal Speech authentication error - check API key")
            elif response.status_code == 400:
                print(f"Unreal Speech bad request: {response.text[:100]}")
            else:
                print(f"Unreal Speech API error: {response.status_code} - {response.text[:100]}")
            
        except requests.exceptions.Timeout:
            print("Unreal Speech API timeout - TTS request took longer than 15 seconds")
        except requests.exceptions.ConnectionError:
            print("Unreal Speech API connection error - check network connectivity")
        except Exception as e:
            print(f"Unexpected error during TTS generation: {str(e)}")
        
        return bytearray(b'')
    
    # Run TTS generation in thread executor to avoid blocking
    output = await asyncio.to_thread(generate_streaming_tts)
    
    if not output:
        print("Failed to generate streaming TTS audio, skipping...")
        return 0
    
    # Calculate audio duration for proper timing (μ-law at 8kHz)
    duration_seconds = len(output) / 8000.0 + 0.3  # Add 300ms buffer

    # Encode the audio data in Base64 format
    encode = base64.b64encode(output).decode('utf-8')

    # Send the audio data via WebSocket to Plivo (handle different WebSocket types)
    audio_message = json.dumps({
        "event": "playAudio",
        "media": {
            "contentType": "audio/x-mulaw",
            "sampleRate": 8000,
            "payload": encode
        }
    })
    
    print(f"🎵 Sending streaming TTS audio: {len(output)} bytes (duration: {duration_seconds:.1f}s)")
    
    # 🛡️ CHECK WEBSOCKET CONNECTION BEFORE SENDING
    if plivo_ws.closed:
        print("⚠️ WebSocket connection is closed, skipping TTS audio send")
        return 0
    
    try:
        # Check if it's aiohttp WebSocket or websockets WebSocket
        if hasattr(plivo_ws, 'send_str'):
            # aiohttp WebSocket
            await plivo_ws.send_str(audio_message)
        else:
            # websockets WebSocket
            await plivo_ws.send(audio_message)
        return duration_seconds  # Return duration for speaking state management
    except Exception as e:
        print(f"❌ Failed to send streaming TTS audio: {str(e)}")
        return 0

# Legacy TTS function - REMOVED in favor of send_streaming_tts()
# All TTS now uses the streaming API for consistent behavior

# All TTS functionality consolidated into send_streaming_tts() - legacy functions removed


# Add a health check endpoint for testing
async def health_handler(request):
    """Simple health check endpoint"""
    return web.Response(text='OK', status=200)


# HTTP endpoints for Plivo integration
async def answer_handler(request):
    """Handle Plivo answer URL - returns XML to start audio streaming"""
    # Get the published Replit app domain
    host = request.headers.get('Host', 'localhost:8080')
    protocol = 'wss' if ('replit.app' in host or 'replit.dev' in host) else 'ws'
    websocket_url = f"{protocol}://{host}/stream?token={WEBSOCKET_AUTH_TOKEN}"
    
    xml_response = f'''
<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Stream bidirectional="true" 
            streamTimeout="3600" 
            keepCallAlive="true"
            contentType="audio/x-mulaw;rate=8000">
        {websocket_url}
    </Stream>
</Response>
'''.strip()
    
    print(f"Answer URL called, returning XML with WebSocket URL: {websocket_url}")
    return web.Response(text=xml_response, content_type='application/xml')

async def hangup_handler(request):
    """Handle Plivo hangup URL - logs call completion"""
    data = await request.text() if request.method == 'POST' else dict(request.query)
    print(f"Call hangup received: {data}")
    return web.Response(text='OK')

async def websocket_handler(request):
    """Handle WebSocket connections for audio streaming"""
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    
    # Check authentication
    from urllib.parse import parse_qs
    query_params = parse_qs(request.query_string)
    token = query_params.get('token', [None])[0]
    
    if token != WEBSOCKET_AUTH_TOKEN:
        print(f'Unauthorized WebSocket connection attempt')
        await ws.close(code=4003)
        return ws
    
    print('Authorized Plivo WebSocket connection established')
    
    # Create session-specific message list to avoid cross-session contamination
    session_messages = []
    session_messages.append({"role": "system", "content": system_msg})
    
    # 🎯 INSTANT GREETING: Send greeting immediately (0ms TTS latency!)
    greeting_duration = await send_greeting_audio(ws)
    if greeting_duration > 0:
        # 🛡️ DURATION-AWARE SPEAKING STATE: Wait for entire greeting to finish
        print(f"🎵 AI speaking for {greeting_duration:.1f}s (greeting)")
        await asyncio.sleep(greeting_duration)  # Wait for actual greeting duration
    
    # 🎯 SETUP ASSEMBLYAI STREAMING: Real-time transcription with turn detection
    streaming_client = await setup_transcription_session(session_messages, ws)
    if not streaming_client:
        print("❌ Failed to establish AssemblyAI session, falling back to basic mode")
        await ws.close()
        return ws
    
    try:
        # Handle WebSocket messages - much simpler with AssemblyAI streaming
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                    
                    # If 'media' event, stream audio directly to AssemblyAI
                    if data['event'] == 'media':
                        media = data['media']
                        
                        # Validate media payload before processing
                        if not media.get('payload'):
                            continue  # Skip empty payloads
                        
                        try:
                            chunk = base64.b64decode(media['payload'], validate=True)
                            
                            # Validate chunk size (Plivo typically sends 160 bytes at 8kHz, 20ms chunks)
                            if len(chunk) == 0:
                                continue  # Skip empty chunks
                            elif len(chunk) > 1600:  # > 200ms at 8kHz seems excessive 
                                print(f"⚠️ Large audio chunk: {len(chunk)} bytes")
                            
                            # Stream the audio chunk directly to AssemblyAI
                            # AssemblyAI handles turn detection and will trigger callbacks
                            streaming_client.stream_audio_chunk(chunk)
                            
                        except (ValueError, Exception) as e:
                            print(f"❌ Error processing audio chunk: {e}")
                            continue  # Skip malformed chunks but keep processing
                    
                    # Handle stream events
                    elif data['event'] == 'start':
                        print("🔄 Audio stream started")
                    elif data['event'] == 'stop':
                        print("🔄 Audio stream stopped")
                        break
                        
                except Exception as e:
                    print(f"Error processing WebSocket message: {e}")
                    traceback.print_exc()
            elif msg.type == WSMsgType.ERROR:
                print(f"WebSocket error: {ws.exception()}")
                
    except Exception as e:
        print(f"WebSocket connection error: {e}")
        traceback.print_exc()
    finally:
        # Clean up AssemblyAI session when WebSocket closes
        await cleanup_transcription_session()
        print("🔚 WebSocket session ended")
    
    return ws

# Main function to start both HTTP and WebSocket servers
async def start_server():
    # Create aiohttp web application
    app = web.Application()
    
    # Add CORS support
    cors = aiohttp_cors.setup(app, defaults={
        "*": aiohttp_cors.ResourceOptions(
            allow_credentials=True,
            expose_headers="*",
            allow_headers="*",
            allow_methods="*"
        )
    })
    
    # Add HTTP routes for Plivo
    app.router.add_get('/answer', answer_handler)
    app.router.add_post('/answer', answer_handler)
    app.router.add_get('/hangup', hangup_handler)
    app.router.add_post('/hangup', hangup_handler)
    app.router.add_get('/health', health_handler)
    
    # Add WebSocket route
    app.router.add_get('/stream', websocket_handler)
    
    # Add CORS to all routes
    for route in list(app.router.routes()):
        cors.add(route)
    
    # Start the server - bind to Replit's platform PORT
    port = int(os.environ.get("PORT", "5000"))
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', port)
    await site.start()
    
    print(f"Voice Agent server starting on 0.0.0.0:{port}")
    print(f"Binding to environment PORT: {port}")
    print("HTTP endpoints: /answer, /hangup")
    print("WebSocket endpoint: /stream")
    print("Server is ready and listening for connections...")
    print(f"Using OpenAI model: {OPENAI_MODEL}")
    print(f"Access URLs:")
    print(f"  Answer URL: https://plivo-audiostream-integration-guides-umer8.replit.app/answer")
    print(f"  Hangup URL: https://plivo-audiostream-integration-guides-umer8.replit.app/hangup")
    
    # Keep the server running
    while True:
        await asyncio.sleep(3600)

def main():
    # Run the async server
    asyncio.run(start_server())


# Entry point for running the script
if __name__ == '__main__':
    sys.exit(main() or 0)
