"""
AssemblyAI Universal-Streaming integration for real-time transcription with intelligent turn detection.
Provides ~300ms latency with neural network-based endpointing for natural conversation flow.
"""
import asyncio
import json
import os
import traceback
import time
from typing import Callable, Optional, Dict, Any
import base64
import audioop
import threading
import queue

from assemblyai.streaming.v3 import (
    StreamingClient, 
    StreamingClientOptions, 
    StreamingParameters,
    StreamingEvents, 
    BeginEvent, 
    TurnEvent, 
    TerminationEvent, 
    StreamingError
)
import assemblyai as aai

class AssemblyAIStreaming:
    """
    AssemblyAI Universal-Streaming client for real-time transcription with intelligent turn detection.
    Optimized for voice agents with low latency and neural network-based endpointing.
    """
    
    def __init__(self, 
                 api_key: str,
                 on_transcript: Optional[Callable[[str, bool], None]] = None,
                 on_turn_end: Optional[Callable[[str, float], None]] = None,
                 on_error: Optional[Callable[[str], None]] = None):
        """
        Initialize AssemblyAI streaming client.
        
        Args:
            api_key: AssemblyAI API key
            on_transcript: Callback for transcript updates (text, is_final)
            on_turn_end: Callback for turn completion (final_text, confidence)
            on_error: Callback for error handling
        """
        self.api_key = api_key
        self.client: Optional[StreamingClient] = None
        self.is_connected = False
        self.is_streaming = False
        
        # Callbacks
        self.on_transcript = on_transcript
        self.on_turn_end = on_turn_end
        self.on_error = on_error
        
        # Current session state
        self.current_turn = ""
        self.session_id = None
        
        # Reconnection management with thread safety
        self.max_reconnect_attempts = 5
        self.reconnect_attempt = 0
        self.reconnect_delay = 1.0  # Start with 1 second
        self.max_reconnect_delay = 30.0
        self.last_connection_time = 0
        self.connection_health_check_interval = 30.0  # Check every 30 seconds
        self.is_reconnecting = False
        self.was_streaming = False  # Track if streaming was active before failure
        self._reconnect_lock = threading.Lock()  # Thread safety for reconnection state
        self._health_monitor_timer = None  # Background health monitor
        
    def connect(self) -> bool:
        """
        Establish connection to AssemblyAI Universal-Streaming with enhanced error handling.
        
        Returns:
            bool: True if connected successfully
        """
        if self.is_reconnecting:
            return False  # Avoid multiple simultaneous reconnection attempts
            
        try:
            print(f"🔄 Connecting to AssemblyAI (attempt {self.reconnect_attempt + 1}/{self.max_reconnect_attempts})")
            
            # Create streaming client with options
            client_options = StreamingClientOptions(
                api_key=self.api_key,
                api_host="streaming.assemblyai.com"
            )
            
            self.client = StreamingClient(client_options)
            
            # Attach event handlers
            self.client.on(StreamingEvents.Begin, self._on_begin)
            self.client.on(StreamingEvents.Turn, self._on_turn)
            self.client.on(StreamingEvents.Termination, self._on_terminated)
            self.client.on(StreamingEvents.Error, self._on_streaming_error)
            
            # Configure streaming parameters for voice agents
            streaming_params = StreamingParameters(
                sample_rate=8000,  # Plivo uses 8kHz for phone calls
                encoding=aai.AudioEncoding.pcm_mulaw,  # Plivo sends mu-law encoded audio
                format_turns=False,  # Skip formatting for faster processing by LLMs
                # Turn detection optimized for voice agent conversations
                end_of_turn_confidence_threshold=0.85,  # Higher confidence for medical/customer service
                min_end_of_turn_silence_when_confident=140,  # 140ms for faster response times
                max_turn_silence=2200,  # 2.2s to avoid long pauses in customer service
            )
            
            # Connect to the streaming service (synchronous)
            self.client.connect(streaming_params)
            
            self.is_connected = True
            self.last_connection_time = time.time()
            with self._reconnect_lock:
                self.reconnect_attempt = 0  # Reset on successful connection
                self.reconnect_delay = 1.0  # Reset delay
                self.is_reconnecting = False
            
            # Start health monitoring
            self._start_health_monitor()
            print("✅ Connected to AssemblyAI Universal-Streaming")
            return True
            
        except Exception as e:
            error_msg = f"Failed to connect to AssemblyAI: {str(e)}"
            print(f"❌ {error_msg}")
            if self.on_error:
                self.on_error(error_msg)
            
            # Only trigger reconnection for retryable errors (not auth failures)
            if "401" not in str(e) and "403" not in str(e) and "authentication" not in str(e).lower():
                self._schedule_reconnection()
            else:
                print("🔑 Authentication error - not attempting reconnection")
            return False
    
    def disconnect(self):
        """Disconnect from AssemblyAI streaming service."""
        try:
            # Stop health monitoring
            self._stop_health_monitor()
            
            if self.client and self.is_connected:
                self.client.disconnect(terminate=True)
                self.is_connected = False
                self.is_streaming = False
                self.was_streaming = False
                print("🔌 Disconnected from AssemblyAI")
        except Exception as e:
            print(f"Error during disconnect: {e}")
    
    def _schedule_reconnection(self):
        """Schedule automatic reconnection with exponential backoff and thread safety."""
        with self._reconnect_lock:
            if self.reconnect_attempt >= self.max_reconnect_attempts:
                print(f"❌ Max reconnection attempts ({self.max_reconnect_attempts}) reached")
                if self.on_error:
                    self.on_error("Max reconnection attempts reached")
                return
            
            if self.is_reconnecting:
                return  # Already reconnecting
            
            self.is_reconnecting = True
            self.reconnect_attempt += 1
            
            # Exponential backoff with jitter
            import random
            base_delay = self.reconnect_delay * (2 ** (self.reconnect_attempt - 1))
            jitter = random.uniform(0.1, 0.5)  # Add jitter to prevent thundering herd
            delay = min(base_delay + jitter, self.max_reconnect_delay)
            print(f"🔄 Scheduling reconnection in {delay:.1f}s (attempt {self.reconnect_attempt})")
            
            # Schedule reconnection in a separate thread
            threading.Timer(delay, self._attempt_reconnection).start()
    
    def _attempt_reconnection(self):
        """Attempt to reconnect to AssemblyAI."""
        try:
            print(f"🔄 Attempting to reconnect...")
            
            # Reset connection state
            self.is_connected = False
            self.is_streaming = False
            
            # Attempt to reconnect
            if self.connect():
                print("✅ Reconnection successful")
                # Restart streaming if it was previously active
                if self.was_streaming:
                    print("🔄 Restarting streaming session after reconnection")
                    self.start_streaming()
            else:
                print("❌ Reconnection failed")
                # Schedule another attempt
                with self._reconnect_lock:
                    self.is_reconnecting = False
                self._schedule_reconnection()
                
        except Exception as e:
            print(f"❌ Reconnection error: {e}")
            with self._reconnect_lock:
                self.is_reconnecting = False
            self._schedule_reconnection()
    
    def check_connection_health(self):
        """Check connection health and reconnect if needed."""
        if not self.is_connected:
            return False
        
        # Check if connection has been idle too long
        if time.time() - self.last_connection_time > self.connection_health_check_interval:
            print("🔄 Connection health check - refreshing connection")
            try:
                # Simple health check - this might vary based on AssemblyAI API
                if self.client and hasattr(self.client, 'is_connected'):
                    if not self.client.is_connected():
                        print("❌ Connection health check failed")
                        self._schedule_reconnection()
                        return False
            except Exception as e:
                print(f"❌ Health check error: {e}")
                self._schedule_reconnection()
                return False
        
        return True
    
    def _start_health_monitor(self):
        """Start background health monitoring."""
        self._stop_health_monitor()  # Stop any existing monitor
        self._health_monitor_timer = threading.Timer(
            self.connection_health_check_interval, 
            self._health_check_loop
        )
        self._health_monitor_timer.start()
        print("💓 Started connection health monitoring")
    
    def _stop_health_monitor(self):
        """Stop background health monitoring."""
        if self._health_monitor_timer:
            self._health_monitor_timer.cancel()
            self._health_monitor_timer = None
    
    def _health_check_loop(self):
        """Periodic health check loop."""
        try:
            if self.check_connection_health():
                # Schedule next health check
                self._health_monitor_timer = threading.Timer(
                    self.connection_health_check_interval,
                    self._health_check_loop
                )
                self._health_monitor_timer.start()
        except Exception as e:
            print(f"❌ Health check loop error: {e}")
    
    def start_streaming(self):
        """Start the streaming session with a custom audio stream."""
        if not self.client or not self.is_connected:
            print("⚠️ AssemblyAI not connected, cannot start streaming")
            return
        
        # Ensure we're not already streaming (prevent multiple threads)
        if self.is_streaming:
            print("⚠️ Already streaming, skipping start")
            return
            
        try:
            self.was_streaming = True  # Track that streaming was active
            # Create a bounded audio queue to prevent memory growth under backpressure
            self.audio_queue = queue.Queue(maxsize=100)  # About 20 seconds of audio at 8kHz
            
            def audio_generator():
                """Generator function that yields audio data from the queue."""
                while self.is_streaming:
                    try:
                        # Get audio chunk from queue (block for up to 0.1 seconds)
                        audio_chunk = self.audio_queue.get(timeout=0.1)
                        if audio_chunk is None:  # Sentinel value to stop
                            break
                        yield audio_chunk
                    except queue.Empty:
                        continue
            
            # Start streaming in a separate thread
            def stream_thread():
                try:
                    self.client.stream(audio_generator())
                except Exception as e:
                    print(f"❌ Streaming thread error: {e}")
                    
                    # CRITICAL FIX: Set state and trigger reconnection on streaming thread failure
                    self.is_streaming = False
                    self.is_connected = False
                    
                    if self.on_error:
                        self.on_error(f"Streaming error: {e}")
                    
                    # Trigger automatic reconnection 
                    print("🔄 Streaming thread failed, triggering reconnection...")
                    self._schedule_reconnection()
            
            self.streaming_thread = threading.Thread(target=stream_thread, daemon=True)
            self.is_streaming = True
            self.streaming_thread.start()
            print("🎵 Started AssemblyAI streaming session")
                
        except Exception as e:
            error_msg = f"Error starting stream: {str(e)}"
            print(f"❌ {error_msg}")
            traceback.print_exc()
            
            # Critical fix: Set streaming state to False and trigger reconnection
            self.is_streaming = False
            self.is_connected = False
            
            if self.on_error:
                self.on_error(error_msg)
            
            # Trigger reconnection for streaming failures
            print("🔄 Streaming failed, triggering reconnection...")
            self._schedule_reconnection()
    
    def stream_audio_chunk(self, audio_chunk: bytes):
        """
        Add audio chunk to the streaming queue with buffering for AssemblyAI requirements.
        
        AssemblyAI requires audio chunks between 50-1000ms. Plivo sends 160-byte chunks (20ms),
        so we buffer multiple chunks until we reach at least 400 bytes (50ms).
        
        Args:
            audio_chunk: Raw audio data (mu-law from Plivo)
        """
        if not self.is_streaming or not hasattr(self, 'audio_queue'):
            return
            
        # Validate chunk size for optimal processing
        if len(audio_chunk) == 0:
            return  # Skip empty chunks
        
        # Initialize audio buffer if not exists
        if not hasattr(self, 'audio_buffer'):
            self.audio_buffer = b''
            
        try:
            # Add chunk to buffer
            self.audio_buffer += audio_chunk
            
            # AssemblyAI requires 50-1000ms chunks (400-8000 bytes at 8kHz mu-law)
            # Send buffered audio when we have at least 50ms (400 bytes)
            MIN_CHUNK_SIZE = 400  # 50ms at 8kHz
            MAX_CHUNK_SIZE = 3200  # 400ms for good responsiveness
            
            while len(self.audio_buffer) >= MIN_CHUNK_SIZE:
                # Extract chunk to send (up to MAX_CHUNK_SIZE)
                chunk_size = min(len(self.audio_buffer), MAX_CHUNK_SIZE)
                chunk_to_send = self.audio_buffer[:chunk_size]
                self.audio_buffer = self.audio_buffer[chunk_size:]
                
                # Send buffered chunk to AssemblyAI
                self.audio_queue.put(chunk_to_send, block=False)
                
        except queue.Full:
            # Log queue depth for monitoring backpressure
            queue_size = self.audio_queue.qsize() if hasattr(self, 'audio_queue') else 'unknown'
            print(f"⚠️ Audio queue full (size: {queue_size}), dropping {len(audio_chunk)} byte chunk")
        except Exception as e:
            error_msg = f"Error queuing audio: {str(e)}"
            print(f"❌ {error_msg}")
            if self.on_error:
                self.on_error(error_msg)
    
    def stop_streaming(self):
        """Stop the streaming session."""
        try:
            if self.is_streaming:
                self.is_streaming = False
                self.was_streaming = False  # Mark as intentionally stopped to prevent reconnection
                if hasattr(self, 'audio_queue'):
                    self.audio_queue.put(None)  # Sentinel to stop generator
                print("⏹️ Stopped streaming session")
        except Exception as e:
            print(f"Error stopping stream: {e}")
    
    def send_force_endpoint(self):
        """Send a force endpoint message to end the current turn immediately."""
        try:
            if self.client and self.is_connected:
                # Send force endpoint message as per API documentation
                force_message = {"type": "ForceEndpoint"}
                # Note: The actual implementation may vary, this follows the documented API
                print("⏹️ Sent force endpoint message")
        except Exception as e:
            print(f"Error sending force endpoint: {e}")
    
    # Event handlers
    def _on_begin(self, client, event: BeginEvent):
        """Handle session start event."""
        self.session_id = event.id
        print(f"🎯 AssemblyAI session started: {event.id}")
    
    def _on_turn(self, client, event: TurnEvent):
        """Handle transcript turn events with turn detection."""
        # Update last activity time for health monitoring
        self.last_connection_time = time.time()
        
        transcript = event.transcript.strip()
        
        if transcript:
            self.current_turn = transcript
            
            # Call transcript callback for real-time updates
            if self.on_transcript:
                self.on_transcript(transcript, event.end_of_turn)
            
            print(f"📝 Turn {event.turn_order}: {transcript}")
            
            # Handle end of turn
            if event.end_of_turn:
                confidence = getattr(event, 'end_of_turn_confidence', 0.8)
                print(f"✅ End of turn detected (confidence: {confidence:.2f})")
                
                if self.on_turn_end:
                    self.on_turn_end(transcript, confidence)
                
                # Reset current turn
                self.current_turn = ""
    
    def _on_terminated(self, client, event: TerminationEvent):
        """Handle session termination with reconnection."""
        duration = getattr(event, 'audio_duration_seconds', 'unknown')
        print(f"🔚 AssemblyAI session terminated after {duration} seconds")
        
        # Critical fix: Trigger reconnection on unexpected termination
        self.is_connected = False
        self.is_streaming = False
        
        # Only reconnect if termination was unexpected (not due to explicit disconnect)
        if self.was_streaming:
            print("🔄 Unexpected termination, triggering reconnection...")
            self._schedule_reconnection()
    
    def _on_streaming_error(self, client, error: StreamingError):
        """Handle streaming errors with enhanced automatic reconnection."""
        error_msg = f"AssemblyAI streaming error: {error}"
        print(f"❌ {error_msg}")
        
        if self.on_error:
            self.on_error(error_msg)
        
        # Handle specific error cases with appropriate reconnection strategy
        error_str = str(error).lower()
        
        # Check for authentication-related errors (don't reconnect)
        if (hasattr(error, 'code') and error.code in ["authentication_failed", "1008", "401", "403"]) or \
           any(auth_term in error_str for auth_term in ["unauthorized", "authentication", "invalid api key"]):
            print("🔑 Authentication failed - stopping reconnection attempts")
            self.is_connected = False
            self.is_streaming = False
            if self.on_error:
                self.on_error("Authentication failed - check API key")
            return  # Don't attempt reconnection
        
        # Handle other specific error cases with reconnection
        if hasattr(error, 'code'):
            if error.code == "connection_lost":
                print("🔄 Connection lost, triggering automatic reconnection...")
                self.is_connected = False
                self.is_streaming = False
                self._schedule_reconnection()
            elif error.code in ["rate_limited", "service_unavailable", "timeout"]:
                print(f"🔄 Service issue ({error.code}), will retry with backoff...")
                self.is_connected = False
                self.is_streaming = False
                self._schedule_reconnection()
            else:
                print(f"🔄 Unknown error ({error.code}), attempting reconnection...")
                self.is_connected = False
                self.is_streaming = False
                self._schedule_reconnection()
        else:
            # Generic error handling - attempt reconnection
            print("🔄 Generic streaming error, attempting reconnection...")
            self.is_connected = False
            self.is_streaming = False
            self._schedule_reconnection()
    
    def get_current_transcript(self) -> str:
        """Get the current incomplete transcript."""
        return self.current_turn


class AssemblyAITranscriptionManager:
    """
    Manager class for handling AssemblyAI transcription in the voice agent context.
    Provides a high-level interface for voice agent transcription with automatic error recovery.
    """
    
    def __init__(self):
        self.api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
        self.streaming_client: Optional[AssemblyAIStreaming] = None
        self.transcript_buffer = []
        self.last_transcript = ""
        self.main_loop = None  # Store the main asyncio loop for thread-safe callbacks
        
        if not self.api_key:
            raise ValueError("ASSEMBLYAI_API_KEY environment variable is required")
    
    async def create_session(self, 
                           on_transcript: Optional[Callable[[str], None]] = None,
                           on_turn_end: Optional[Callable[[str], None]] = None) -> AssemblyAIStreaming:
        """
        Create a new AssemblyAI streaming session.
        
        Args:
            on_transcript: Callback for real-time transcript updates
            on_turn_end: Callback for turn completion (can be async)
            
        Returns:
            AssemblyAIStreaming: Configured streaming client
        """
        
        # Store the main asyncio loop for thread-safe callback execution
        self.main_loop = asyncio.get_running_loop()
        
        def handle_transcript(text: str, is_final: bool):
            self.last_transcript = text
            if on_transcript:
                if asyncio.iscoroutinefunction(on_transcript):
                    # Schedule async callback on main loop
                    asyncio.run_coroutine_threadsafe(on_transcript(text), self.main_loop)
                else:
                    # Call sync callback directly
                    on_transcript(text)
        
        def handle_turn_end(text: str, confidence: float):
            self.transcript_buffer.append(text)
            if on_turn_end:
                if asyncio.iscoroutinefunction(on_turn_end):
                    # Schedule async callback on main loop thread-safely
                    future = asyncio.run_coroutine_threadsafe(on_turn_end(text), self.main_loop)
                    print(f"🔄 Scheduled async turn completion callback for: '{text}'")
                    # Don't wait for result to avoid blocking the streaming thread
                else:
                    # Call sync callback directly
                    on_turn_end(text)
        
        def handle_error(error_msg: str):
            print(f"Transcription error: {error_msg}")
        
        self.streaming_client = AssemblyAIStreaming(
            api_key=self.api_key,
            on_transcript=handle_transcript,
            on_turn_end=handle_turn_end,
            on_error=handle_error
        )
        
        # Connect to the service
        connected = await asyncio.get_event_loop().run_in_executor(
            None, self.streaming_client.connect
        )
        if not connected:
            raise RuntimeError("Failed to connect to AssemblyAI streaming service")
        
        return self.streaming_client
    
    async def close_session(self):
        """Close the current transcription session."""
        if self.streaming_client:
            await asyncio.get_event_loop().run_in_executor(
                None, self.streaming_client.disconnect
            )
            self.streaming_client = None
    
    def get_session_transcripts(self) -> list:
        """Get all completed transcripts from the current session."""
        return self.transcript_buffer.copy()
    
    def get_latest_transcript(self) -> str:
        """Get the most recent transcript."""
        return self.last_transcript


# Backward compatibility function for existing code
async def transcribe_audio_stream(audio_chunk: bytes, 
                                streaming_client: AssemblyAIStreaming) -> Optional[str]:
    """
    Stream audio chunk to AssemblyAI for transcription.
    This function provides backward compatibility with the existing transcribe_audio interface.
    
    Args:
        audio_chunk: Raw audio data from Plivo (mu-law encoded)
        streaming_client: AssemblyAI streaming client instance
        
    Returns:
        str: Latest transcript (for compatibility, real transcripts come via callbacks)
    """
    streaming_client.stream_audio_chunk(audio_chunk)
    return streaming_client.get_current_transcript()