# AI Voice Agent System - Phone Call Integration
*Created by Umer Abdullah*

This repository contains an advanced AI-powered voice agent system that enables natural phone conversations using cutting-edge speech processing and AI technologies.

## 🎯 Voice Agent - Live Production System

**Created by Umer Abdullah**

Our flagship voice agent is a production-ready system that transforms phone calls into intelligent conversations. This sophisticated system integrates multiple AI services to create seamless voice interactions:

### 🚀 What We're Building

We've created a complete **AI receptionist for Tech Hospital** that handles phone inquiries with human-like conversation abilities. The system:

- **Answers phone calls automatically** via Plivo telephony integration
- **Understands speech in real-time** using AssemblyAI Universal-Streaming (~300ms latency)
- **Generates intelligent responses** through OpenAI's GPT models with optimized streaming
- **Converts responses to natural speech** using Unreal Speech's high-quality TTS
- **Maintains conversation context** with smart memory management
- **Provides business-specific responses** for phone repair bookings, pricing, and appointments

### 🔧 Technical Architecture

**Real-Time Speech Processing Pipeline:**
1. **Plivo Audio Streaming** - Receives μ-law PCM audio from phone calls at 8kHz
2. **Audio Buffering** - Intelligent chunk management (50-400ms) for optimal processing
3. **AssemblyAI Universal-Streaming** - Neural network-based turn detection with 300ms transcription latency
4. **OpenAI Integration** - Streaming GPT responses with context trimming and performance optimization
5. **Unreal Speech TTS** - High-quality voice synthesis with telephony-optimized output
6. **WebSocket Communication** - Secure real-time bidirectional audio streaming

### 🎛️ Advanced Features

- **Intelligent Turn Detection**: Neural network-based endpointing eliminates traditional voice activity detection
- **Context Management**: Automatic conversation trimming prevents token overflow while maintaining context
- **Error Recovery**: Robust reconnection system with exponential backoff for service interruptions
- **Performance Optimization**: Sub-second response times through streaming APIs and efficient audio processing
- **Production Security**: Token-based WebSocket authentication with environment variable management

### 🌟 Performance Achievements

- **~300ms speech-to-text latency** (AssemblyAI Universal-Streaming)
- **Sub-second total response time** (optimized OpenAI streaming + Unreal Speech)
- **Zero cache overhead** (removed for faster, more natural responses)
- **Reliable audio processing** (handles Plivo's 160-byte/20ms chunks with proper buffering)
- **Automatic error recovery** with production-grade reliability

---

## 📋 Quick Start

**Created by Umer Abdullah**

1. **Environment Setup**: Configure API keys for AssemblyAI, OpenAI, and Unreal Speech
2. **Server Launch**: Run `python voiceagent/server.py` to start the voice agent
3. **Plivo Integration**: Point your Plivo webhook to the Answer URL provided by the server
4. **Live Testing**: Place a call and experience natural AI conversation

### 📞 Production Deployment

The system runs on Replit with VM deployment for always-on availability. The voice agent handles multiple concurrent calls with session isolation and maintains conversation state throughout each interaction.

**Answer URL Format**: `https://your-replit-domain.dev/answer`
**WebSocket Endpoint**: `wss://your-replit-domain.dev/stream?token=your-auth-token`

### 🔗 Additional Integration Examples

- **Dialogflow Integration**: Express application with Plivo audio streaming for NLU-powered voice interactions *(Created by Umer Abdullah)*
- **Sentiment Analysis**: Real-time call analysis using Amazon Transcribe and Comprehend with S3 storage for post-call insights *(Created by Umer Abdullah)*

---

## 🏆 About the Developer

**Umer Abdullah** - Specialist in advanced AI voice solutions for modern businesses

This project represents cutting-edge integration of multiple AI services to create production-ready voice agents that deliver natural, intelligent phone conversations with enterprise-level reliability and performance.

---

*All implementations created by Umer Abdullah - Advanced AI voice solutions for modern businesses*