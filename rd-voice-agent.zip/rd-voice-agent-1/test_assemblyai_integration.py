#!/usr/bin/env python3
"""
Comprehensive integration test for the AssemblyAI voice agent system.
Tests all components without requiring live phone calls.
"""

import asyncio
import json
import time
import sys
import os
import base64
import threading
from typing import Dict, List

# Add the voiceagent directory to the path
sys.path.append('voiceagent')

from assemblyai_streaming import AssemblyAIStreaming, AssemblyAITranscriptionManager

class AssemblyAIIntegrationTest:
    """Comprehensive test suite for AssemblyAI voice agent integration."""
    
    def __init__(self):
        self.test_results: Dict[str, bool] = {}
        self.test_logs: List[str] = []
        self.transcripts_received = []
        self.turn_completions = []
        self.errors_received = []
        
    def log(self, message: str):
        """Log test messages with timestamp."""
        timestamp = time.strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        print(log_message)
        self.test_logs.append(log_message)
    
    def test_api_key_configuration(self) -> bool:
        """Test 1: Verify API key is properly configured."""
        self.log("🔑 Testing API key configuration...")
        
        try:
            api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            if not api_key:
                self.log("❌ ASSEMBLYAI_API_KEY not found in environment")
                return False
            
            if len(api_key) < 10:  # Basic validation
                self.log("❌ ASSEMBLYAI_API_KEY appears to be invalid (too short)")
                return False
            
            self.log("✅ API key is properly configured")
            return True
            
        except Exception as e:
            self.log(f"❌ API key test failed: {e}")
            return False
    
    def test_streaming_client_initialization(self) -> bool:
        """Test 2: Test AssemblyAI streaming client initialization."""
        self.log("🔧 Testing AssemblyAI streaming client initialization...")
        
        try:
            # Test callbacks
            def on_transcript(text: str, is_final: bool):
                self.transcripts_received.append((text, is_final))
                self.log(f"📝 Transcript: {text} (final: {is_final})")
            
            def on_turn_end(text: str, confidence: float):
                self.turn_completions.append((text, confidence))
                self.log(f"✅ Turn complete: {text} (confidence: {confidence:.2f})")
            
            def on_error(error_msg: str):
                self.errors_received.append(error_msg)
                self.log(f"❌ Error: {error_msg}")
            
            # Initialize client
            api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            client = AssemblyAIStreaming(
                api_key=api_key,
                on_transcript=on_transcript,
                on_turn_end=on_turn_end,
                on_error=on_error
            )
            
            # Verify initialization
            if not client.api_key:
                self.log("❌ Client initialization failed - no API key")
                return False
            
            if client.is_connected:
                self.log("❌ Client should not be connected initially")
                return False
            
            self.log("✅ Streaming client initialized successfully")
            return True
            
        except Exception as e:
            self.log(f"❌ Client initialization test failed: {e}")
            return False
    
    def test_transcription_manager(self) -> bool:
        """Test 3: Test AssemblyAI transcription manager."""
        self.log("🎯 Testing AssemblyAI transcription manager...")
        
        try:
            manager = AssemblyAITranscriptionManager()
            
            # Verify initialization
            if not manager.api_key:
                self.log("❌ Manager initialization failed - no API key")
                return False
            
            if manager.streaming_client is not None:
                self.log("❌ Manager should not have a client initially")
                return False
            
            self.log("✅ Transcription manager initialized successfully")
            return True
            
        except Exception as e:
            self.log(f"❌ Manager test failed: {e}")
            return False
    
    def test_connection_attempt(self) -> bool:
        """Test 4: Test connection to AssemblyAI (with timeout)."""
        self.log("🌐 Testing connection to AssemblyAI...")
        
        try:
            api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            client = AssemblyAIStreaming(
                api_key=api_key,
                on_transcript=lambda t, f: None,
                on_turn_end=lambda t, c: None,
                on_error=lambda e: self.log(f"Connection error: {e}")
            )
            
            # Attempt connection with timeout
            start_time = time.time()
            connected = client.connect()
            connection_time = time.time() - start_time
            
            self.log(f"Connection attempt took {connection_time:.2f}s")
            
            if connected:
                self.log("✅ Successfully connected to AssemblyAI")
                
                # Test disconnect
                client.disconnect()
                self.log("✅ Successfully disconnected from AssemblyAI")
                return True
            else:
                self.log("❌ Failed to connect to AssemblyAI")
                return False
                
        except Exception as e:
            self.log(f"❌ Connection test failed: {e}")
            return False
    
    def test_error_handling(self) -> bool:
        """Test 5: Test error handling and reconnection logic."""
        self.log("🛡️ Testing error handling and reconnection logic...")
        
        try:
            # Test with invalid API key
            invalid_client = AssemblyAIStreaming(
                api_key="invalid_key_test",
                on_transcript=lambda t, f: None,
                on_turn_end=lambda t, c: None,
                on_error=lambda e: self.log(f"Expected error: {e}")
            )
            
            # This should fail
            connected = invalid_client.connect()
            if connected:
                self.log("❌ Connection should have failed with invalid API key")
                return False
            
            self.log("✅ Error handling works correctly for invalid API key")
            
            # Test reconnection state management
            valid_api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            test_client = AssemblyAIStreaming(
                api_key=valid_api_key,
                on_transcript=lambda t, f: None,
                on_turn_end=lambda t, c: None,
                on_error=lambda e: None
            )
            
            # Test reconnection properties
            if test_client.max_reconnect_attempts != 5:
                self.log("❌ Incorrect max reconnection attempts")
                return False
            
            if test_client.reconnect_delay != 1.0:
                self.log("❌ Incorrect initial reconnection delay")
                return False
            
            self.log("✅ Error handling configuration is correct")
            return True
            
        except Exception as e:
            self.log(f"❌ Error handling test failed: {e}")
            return False
    
    def test_turn_detection_configuration(self) -> bool:
        """Test 6: Validate turn detection parameters."""
        self.log("🎯 Testing turn detection configuration...")
        
        try:
            api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            client = AssemblyAIStreaming(
                api_key=api_key,
                on_transcript=lambda t, f: None,
                on_turn_end=lambda t, c: None,
                on_error=lambda e: None
            )
            
            # We can't easily inspect the streaming parameters without connecting,
            # but we can verify the client has the expected structure
            if not hasattr(client, 'is_connected'):
                self.log("❌ Client missing connection state")
                return False
            
            if not hasattr(client, 'is_streaming'):
                self.log("❌ Client missing streaming state")
                return False
            
            if not hasattr(client, '_reconnect_lock'):
                self.log("❌ Client missing thread safety lock")
                return False
            
            self.log("✅ Turn detection configuration structure is correct")
            return True
            
        except Exception as e:
            self.log(f"❌ Turn detection test failed: {e}")
            return False
    
    def test_audio_processing_pipeline(self) -> bool:
        """Test 7: Test audio processing capabilities."""
        self.log("🎵 Testing audio processing pipeline...")
        
        try:
            # Create sample mu-law audio data (silence)
            sample_audio = b'\xff' * 160  # 160 bytes of mu-law silence (20ms at 8kHz)
            
            api_key = os.environ.get('ASSEMBLYAI_API_KEY', '')
            client = AssemblyAIStreaming(
                api_key=api_key,
                on_transcript=lambda t, f: None,
                on_turn_end=lambda t, c: None,
                on_error=lambda e: None
            )
            
            # Test audio processing without connection (should handle gracefully)
            client.stream_audio_chunk(sample_audio)  # Should not crash
            
            # Test empty audio chunk handling
            client.stream_audio_chunk(b'')  # Should be ignored
            
            self.log("✅ Audio processing pipeline handles input correctly")
            return True
            
        except Exception as e:
            self.log(f"❌ Audio processing test failed: {e}")
            return False
    
    async def run_all_tests(self) -> Dict[str, bool]:
        """Run all integration tests."""
        self.log("🚀 Starting AssemblyAI Integration Test Suite")
        self.log("=" * 60)
        
        tests = [
            ("API Key Configuration", self.test_api_key_configuration),
            ("Streaming Client Init", self.test_streaming_client_initialization),
            ("Transcription Manager", self.test_transcription_manager),
            ("Connection Attempt", self.test_connection_attempt),
            ("Error Handling", self.test_error_handling),
            ("Turn Detection Config", self.test_turn_detection_configuration),
            ("Audio Processing", self.test_audio_processing_pipeline),
        ]
        
        for test_name, test_func in tests:
            self.log(f"\n📋 Running: {test_name}")
            try:
                result = test_func()
                self.test_results[test_name] = result
                if result:
                    self.log(f"✅ {test_name}: PASSED")
                else:
                    self.log(f"❌ {test_name}: FAILED")
            except Exception as e:
                self.log(f"💥 {test_name}: CRASHED - {e}")
                self.test_results[test_name] = False
        
        # Print summary
        self.log("\n" + "=" * 60)
        self.log("📊 TEST SUMMARY")
        self.log("=" * 60)
        
        passed = sum(1 for result in self.test_results.values() if result)
        total = len(self.test_results)
        
        for test_name, result in self.test_results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            self.log(f"{status} | {test_name}")
        
        self.log(f"\nResults: {passed}/{total} tests passed")
        
        if passed == total:
            self.log("🎉 ALL TESTS PASSED - System ready for live calls!")
        else:
            self.log("⚠️ Some tests failed - review issues before live deployment")
        
        return self.test_results

# Live Testing Guide
LIVE_TESTING_GUIDE = """
🎯 LIVE TESTING GUIDE FOR ASSEMBLYAI VOICE AGENT
===============================================

After running the integration tests, follow these steps for live testing:

1. 📞 PHONE CALL SETUP:
   - Use the Plivo Answer URL: https://plivo-audiostream-integration-guides-umer8.replit.app/answer
   - Configure Plivo application to use this URL
   - Make test calls to validate end-to-end functionality

2. 🎯 TURN DETECTION VALIDATION:
   - Test with short phrases: "Hello", "Yes", "No" 
   - Test with longer sentences: "I need help with my account"
   - Test with questions: "What are your hours?"
   - Test with pauses: Natural speech with brief hesitations
   - Verify AI responds at natural conversation breaks

3. ⚡ LATENCY TESTING:
   - Measure time from end of speech to start of AI response
   - Target: < 500ms total latency (150ms transcription + 300ms AI + 50ms TTS)
   - Test under different network conditions

4. 🛡️ ERROR RECOVERY TESTING:
   - Interrupt network connection during call
   - Test with poor audio quality
   - Test with background noise
   - Verify system recovers gracefully

5. 📊 MONITORING CHECKLIST:
   - Watch server logs for errors
   - Monitor AssemblyAI connection health
   - Check turn detection confidence scores
   - Verify proper session cleanup

6. 🎵 AUDIO QUALITY VALIDATION:
   - Test with different microphones
   - Test with mobile vs landline calls
   - Verify speech recognition accuracy
   - Check for audio dropouts or distortion

Expected Performance Metrics:
• Turn detection latency: ~140ms
• Transcription accuracy: >95% for clear speech  
• Connection uptime: >99.9%
• Recovery time: <5 seconds for network issues
"""

if __name__ == "__main__":
    async def main():
        tester = AssemblyAIIntegrationTest()
        results = await tester.run_all_tests()
        
        print("\n" + LIVE_TESTING_GUIDE)
        
        # Return exit code based on results
        if all(results.values()):
            sys.exit(0)  # All tests passed
        else:
            sys.exit(1)  # Some tests failed
    
    asyncio.run(main())