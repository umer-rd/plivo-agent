# Voice Agent Project Setup

## Overview
This project is a Python-based voice agent that integrates multiple AI services to provide real-time voice conversations through phone calls. The system uses Plivo for voice streaming, AssemblyAI Universal-Streaming for fast speech-to-text (~300ms latency), OpenAI for conversation generation, and Unreal Speech for text-to-speech conversion.

## Current State
- ✅ Successfully migrated from GitHub import to Replit environment
- ✅ All Python dependencies installed and configured
- ✅ Environment variables set up for secure API key management
- ✅ WebSocket server running on 0.0.0.0:8080 with authentication protection
- ✅ Session isolation implemented to prevent cross-conversation contamination
- ✅ Async/await properly configured for non-blocking operations
- ✅ Deployment configured as VM service for long-running operation

## Architecture
- **Main Application**: `voiceagent/server.py` - WebSocket server handling voice conversations
- **Dependencies**: All listed in `voiceagent/requirements.txt` and root `requirements.txt`
- **Authentication**: WebSocket endpoint protected with token authentication
- **API Integrations**: AssemblyAI Universal-Streaming (STT), OpenAI (conversation), Unreal Speech (TTS), Plivo (voice streaming)

## Environment Variables Required
- `ASSEMBLYAI_API_KEY` - Speech-to-text service with Universal-Streaming
- `OPENAI_API_KEY` - Conversation generation
- `UNREAL_SPEECH_API_KEY` - Text-to-speech conversion (Unreal Speech)
- `WEBSOCKET_AUTH_TOKEN` - WebSocket endpoint protection (optional, defaults to demo token)
- `OPENAI_MODEL` - OpenAI model to use (optional, defaults to gpt-4.1-mini)

## WebSocket Endpoint
- **URL**: `ws://your-replit-domain:8080/stream?token=YOUR_AUTH_TOKEN`
- **Protocol**: Expects Plivo audio streaming format
- **Authentication**: Requires valid token in query parameters

## Recent Changes
- Successfully migrated from ElevenLabs to Unreal Speech for TTS (January 2025)
- Implemented μ-law PCM codec for perfect Plivo telephony compatibility
- **Major Performance Optimizations (September 2025):**
  - Context trimming: Prevents exponential token growth by keeping only system + last 6 messages
  - System prompt compression: Reduced from 800+ words to ~60 words while preserving functionality
  - OpenAI API tuning: Added max_tokens=120, temperature=0.7, presence_penalty=0.1, 12s timeout
  - Chunking optimization: Reduced thresholds to 45 chars and 400ms for faster first audio
  - Fixed content-dropping bug: Ensures no text is lost during streaming
  - Consistent context management across cached and non-cached response paths
- **Unreal Speech Streaming API Integration (September 2025):**
  - Removed OpenAI response chunking in favor of complete response streaming
  - Implemented `send_streaming_tts()` function using Unreal Speech `/stream` endpoint
  - Maintained μ-law PCM format and 8kHz sample rate for telephony compatibility
  - Consolidated all TTS calls to use consistent streaming approach
- **AssemblyAI Universal-Streaming Migration (September 2025):**
  - Migrated from Deepgram to AssemblyAI Universal-Streaming for faster transcription (~300ms latency)
  - Implemented intelligent neural network-based turn detection (140ms threshold)
  - Added comprehensive error handling and automatic reconnection with exponential backoff
  - Optimized audio processing pipeline with strict validation and backpressure management
  - Enhanced connection health monitoring with background checks
  - Removed VAD (Voice Activity Detection) in favor of AssemblyAI's semantic endpointing
- Enhanced TTS with Eleanor voice and telephony-optimized 64k bitrate
- Added explicit 8kHz sample rate for telephony compliance

## User Preferences
- Prefers secure, production-ready configurations
- Uses environment variables for API key management
- Follows Replit deployment best practices